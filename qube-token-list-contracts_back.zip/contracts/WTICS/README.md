# WTICS-Contract
Wrapped TICS | on Qubetics Network

#### WTICS address: 
0x8A0a018caEd522B3f1501616f828f6B1819Ced22
